chrome.runtime.onInstalled.addListener(() => {
    console.log('Boxing Random Extension installed!');
  });