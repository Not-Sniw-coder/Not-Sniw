chrome.runtime.onInstalled.addListener(() => {
    console.log('Volley Random Extension installed!');
  });