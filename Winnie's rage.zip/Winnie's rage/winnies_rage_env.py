import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pygame

class WinniesRageEnv(gym.Env):
    metadata = {"render_modes": ["human"]}

    def __init__(self, render_mode="human"):
        super().__init__()

        # Initialize Pygame
        pygame.init()
        self.screen_width, self.screen_height = 800, 600
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height)) if render_mode == "human" else None
        self.clock = pygame.time.Clock()
        self.render_mode = render_mode

        # Load player sprite
        self.player_sprite = pygame.image.load("Winnie's rage/winnie.png")  # Make sure winnie.png exists
        self.player_sprite = pygame.transform.scale(self.player_sprite, (100, 100))  # Resize to fit

        # Define action space (Left, Right, Jump, No-op)
        self.action_space = spaces.Discrete(4)

        # Define observation space (example: player position & velocity)
        self.observation_space = spaces.Box(
            low=np.array([0, 0, -10, -10]),  # Min values (x, y, vx, vy)
            high=np.array([self.screen_width, self.screen_height, 10, 10]),  # Max values
            dtype=np.float32
        )

        # Initialize game variables
        self.reset()

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)

        # Player start position
        self.player_x = 600
        self.player_y = 400
        self.player_vx = 0
        self.player_vy = 0
        self.done = False

        return np.array([self.player_x, self.player_y, self.player_vx, self.player_vy], dtype=np.float32), {}

    def step(self, action):
        """Apply the action and update the game state."""
        if action == 0:  # Move Left
            self.player_vx = -5
        elif action == 1:  # Move Right
            self.player_vx = 5
        elif action == 2:  # Jump
            if self.player_y == 500:  # Simple ground check
                self.player_vy = -15
        elif action == 3:  # No-op (Do nothing)
            self.player_vx = 0

        # Apply gravity
        self.player_vy += 0.3  # Gravity acceleration
        self.player_y += self.player_vy
        self.player_x += self.player_vx

        # Prevent player from going off-screen
        self.player_x = max(0, min(self.screen_width, self.player_x))
        if self.player_y > 500:
            self.player_y = 500
            self.player_vy = 0

        # Check if the player reaches the trophy (winning condition)
        reward = 0
        if self.player_x >= 750:
            reward = 100
            self.done = True
        else:
            reward = -1  # Small penalty to encourage faster completion

        return np.array([self.player_x, self.player_y, self.player_vx, self.player_vy], dtype=np.float32), reward, self.done, False, {}

    def render(self):
        if self.render_mode == "human":
            self.screen.fill((0, 0, 0))  # Clear screen

            # Draw the player using the sprite
            self.screen.blit(self.player_sprite, (self.player_x, self.player_y))

            pygame.display.flip()
            self.clock.tick(30)

    def close(self):
        pass