import pygame
import sys
import time
import math

# Initialize Pygame
pygame.init()
pygame.mixer.init()  # Initialize the mixer module

life = 5  # Winnie's life
gravity = 0.3  # Gravity force
velocity_y = 0  # Vertical velocity
game_over = False  # Flag to control game over state
start_time = None  # Variable to store the start time

# Set up the display with a larger FOV
screen = pygame.display.set_mode((1200, 800))  # Width: 1200, Height: 800
pygame.display.set_caption("Winnie's Rage")

# Initialize font
pygame.font.init()
font = pygame.font.SysFont(None, 36)
large_font = pygame.font.SysFont(None, 200)  # Increased size for the title
button_font = pygame.font.SysFont(None, 48)  # Increased size for the button text

# Load sound files
game_over_sound = pygame.mixer.Sound("Winnie's Rage/game_over.wav")  # Revert this path

# Colors
background_color = (173, 216, 230)  # Light Blue
text_color = (255, 255, 255)  # White
shadow_color = (0, 0, 0)  # Black
title_color = (255, 255, 0)  # Yellow
title_shadow_color = (255, 0, 0)  # Red
button_color = (255, 255, 255)  # White
button_text_color = (0, 0, 0)  # Black

# Define the Sprite class for Winnie
class Winnie(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image_standing = pygame.image.load("Winnie's Rage/winnie.png").convert_alpha()  # Revert this path
        self.image_standing = pygame.transform.scale(self.image_standing, (100, 100))  # Resize the image to 100x100 pixels
        self.image_run_left = pygame.image.load("Winnie's Rage/winnierunleft.png").convert_alpha()  # Revert this path
        self.image_run_left = pygame.transform.scale(self.image_run_left, (100, 100))  # Resize the image to 100x100 pixels
        self.image_run_right = pygame.image.load("Winnie's Rage/winnierunright.png").convert_alpha()  # Revert this path
        self.image_run_right = pygame.transform.scale(self.image_run_right, (100, 100))  # Resize the image to 100x100 pixels
        self.image = self.image_standing
        self.rect = self.image.get_rect()
        self.rect.center = (600, 400)  # Initial position of the sprite

    def update(self):
        global velocity_y, life, game_over
        if game_over:
            return  # Do not update position if game is over

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= 5  # Move left
            self.image = self.image_run_left  # Change to running left image
        elif keys[pygame.K_RIGHT]:
            self.rect.x += 5  # Move right
            self.image = self.image_run_right  # Change to running right image
        else:
            self.image = self.image_standing  # Change to standing image

        if keys[pygame.K_UP]:
            self.rect.y -= 15  # Move up

        # Apply gravity
        if not keys[pygame.K_e]:  # Check if the "E" key is not pressed
            velocity_y += gravity
            self.rect.y += velocity_y
        if keys[pygame.K_q]:  # Check if the "Q" key is pressed
            life = 999999999  # if q is pressed gets infinite lives

        # Check for vertical collisions
        for wall in walls:
            if self.rect.colliderect(wall.rect):
                if self.rect.bottom > wall.rect.top and self.rect.top < wall.rect.top:
                    self.rect.bottom = wall.rect.top  # Colliding from the top
                    velocity_y = 0  # Reset vertical velocity
                elif self.rect.top < wall.rect.bottom and self.rect.bottom > wall.rect.bottom:
                    self.rect.top = wall.rect.bottom  # Colliding from the bottom
                    velocity_y = 0  # Reset vertical velocity

        # Check for collisions with firewalls
        for firewall in firewalls:
            if self.rect.colliderect(firewall.rect):
                life -= 1  # Decrease life
                self.rect.center = (600, 400)  # Reset position
                velocity_y = 0  # Reset vertical velocity
            
        # Check for collisions with spikes
        for spike in spikes:
            if self.rect.colliderect(spike.rect):
                life -= 1  # Decrease life
                self.rect.center = (600, 400)  # Reset position
                velocity_y = 0  # Reset vertical velocity

        # Check if Winnie falls below the screen
        if self.rect.top > screen.get_height():
            life -= 1  # Decrease life
            if life <= 0:
                game_over = True  # Set game over flag
            else:
                self.rect.center = (600, 400)  # Reset position
                velocity_y = 0  # Reset vertical velocity

# Define the Sprite class for Walls
class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill((0, 0, 0))  # Black color for the wall
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

# Define the Sprite class for FireWalls
class FireWall(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill((255, 0, 0))  # Red color for the wall
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

# Define the Sprite class for Spikes
class Spike(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        super().__init__()
        if direction == 'up':
            self.image = pygame.image.load("Winnie's Rage/spikesup.png").convert_alpha()  # Load the image for spikes pointing up
        elif direction == 'down':
            self.image = pygame.image.load("Winnie's Rage/spikesdown.png").convert_alpha()  # Load the image for spikes pointing down
        elif direction == 'left':
            self.image = pygame.image.load("Winnie's Rage/spikesleft.png").convert_alpha()  # Load the image for spikes pointing left
        elif direction == 'right':
            self.image = pygame.image.load("Winnie's Rage/spikesright.png").convert_alpha()  # Load the image for spikes pointing right
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

# Define the Sprite class for the Trophy
class Trophy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Winnie's Rage/trophy.png").convert_alpha()  # Load trophy image
        self.image = pygame.transform.scale(self.image, (80, 80))  # Resize
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

# Create sprite groups
all_sprites = pygame.sprite.Group()
walls = pygame.sprite.Group()
firewalls = pygame.sprite.Group()
spikes = pygame.sprite.Group()

# Create instances of Winnie and Walls
winnie = Winnie()
all_sprites.add(winnie)

# Create some walls
wall1 = Wall(100, 700, 1000, 20)  # x, y, width, height *starting platform
wall2 = Wall(300, 200, 200, 20)  # Another wall *second jump
wall3 = Wall(600, 300, 300, 20)  # Another wall *first jump
wall4 = Wall(750, -270, 10, 20)  # Another wall *hard jump to parkour
wall5 = Wall(1250, -270, 10, 20)  # Another wall *parkour
wall6 = Wall(1750, -270, 10, 20)  # Another wall *parkour
firewall1 = FireWall(0, -100, 300, 20)  # A fire wall takes 1 life if touched
firewall2 = FireWall(2250, -270, 10, 20)
firewall3 = FireWall(2400, -150, 300, 20) #fall
firewall4 = FireWall(1900, -150, 200, 20) #fall 
firewall5 = FireWall(1850, 100, 300, 20) #fall 
firewall6 = FireWall(2400, 100, 300, 20) #fall 
wall7 = Wall(2250, 400, 10, 20) #land
wall8 = Wall(2250, 800, 1000, 20) #hard jump

walls.add(wall1, wall2, wall3, wall4, wall5, wall6, wall7, wall8)
firewalls.add(firewall1, firewall2, firewall3, firewall4, firewall5, firewall6)
all_sprites.add(wall1, wall2, wall3, wall4, wall5, wall6,firewall1,firewall2,firewall3,firewall4,firewall5,firewall6,wall7,wall8)

# Create spikes
spike1 = Spike(2500, 400, 'up')
#spike2 = Spike(500, 600, 'down')
spike3 = Spike(2900, 740, 'left')
#spike4 = Spike(700, 600, 'right')
spike5 = Spike(2900, 690, 'left')
spike6 = Spike(2900, 640, 'left')
spike7 = Spike(2900, 590, 'left')
spike8 = Spike(2900, 540, 'left')
spike8 = Spike(2900, 375, 'left')
spike9 = Spike(2900, 325, 'left')

trophy = Trophy(3000, 720)  # Adjust position to where you want the win condition
all_sprites.add(trophy)

spikes.add(spike1, spike3,spike5, spike6,spike7,spike8,spike9) #spike2, spike3, spike4
all_sprites.add(spike1, spike3,spike5,spike6,spike7,spike8,spike9) #spike2, spike3, spike4)

# Create non-movable Winnie sprites
winnie_standing = Winnie()
winnie_standing.image = pygame.transform.scale(winnie_standing.image_standing, (400, 400))  # Make it larger
winnie_standing.rect = winnie_standing.image.get_rect()
winnie_standing.rect.bottomleft = (10, screen.get_height() - 10)

winnie_running_left = Winnie()
winnie_running_left.image = pygame.transform.scale(winnie_running_left.image_run_left, (400, 400))  # Make it larger
winnie_running_left.rect = winnie_running_left.image.get_rect()
winnie_running_left.rect.bottomright = (screen.get_width() - 10, screen.get_height() - 10)

# Function to display text with optional shadow
def draw_text(text, font, color, x, y, shadow_color=None):
    if shadow_color:
        shadow = font.render(text, True, shadow_color)
        screen.blit(shadow, (x + 2, y + 2))
    text_surface = font.render(text, True, color)
    screen.blit(text_surface, (x, y))

# Loading screen
def loading_screen():
    for i in range(1, 201):  # Extend the loading screen duration
        screen.fill(background_color)
        draw_text(f'Loading {i}%', font, text_color, 550, 380)
        draw_text("Winnie's Rage", large_font, title_color, 100, 100, title_shadow_color)
        pygame.display.flip()
        time.sleep(0.05)

# Main menu screen
def main_menu(play_again=False):
    global start_time
    start_time = time.time()  # Set the start time when the game starts
    while True:
        screen.fill(background_color)
        elapsed_time = time.time() - start_time
        sine_wave_offset = math.sin(elapsed_time * 2) * 10  # Adjust the speed and amplitude as needed

        draw_text("Winnie's Rage", large_font, title_color, 100, 100 + sine_wave_offset, title_shadow_color)
        
        # Increase the size of the start button and move it closer to the middle
        pygame.draw.rect(screen, shadow_color, (448, 338, 304, 80))  # Draw the black shadow for the button
        pygame.draw.rect(screen, button_color, (450, 340, 300, 76))  # Draw the white button
        button_text = "Play Again" if play_again else "Play"
        draw_text(button_text, button_font, button_text_color, 515, 355)  # Adjust the position of the button text

        # Draw non-movable Winnie sprites
        screen.blit(winnie_standing.image, winnie_standing.rect)
        screen.blit(winnie_running_left.image, winnie_running_left.rect)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = event.pos
                if 450 <= mouse_x <= 750 and 340 <= mouse_y <= 416:  # Update the button click area
                    return  # Start the game

# Game over screen
def game_over_screen():
    game_over_sound.play()  # Play the game over sound
    draw_text("Game Over", large_font, text_color, 300, 300, shadow_color)
    pygame.display.flip()
    time.sleep(3)  # Display the game over screen for 3 seconds

# Main game loop
def game_loop():
    global life, game_over, start_time
    start_time = time.time()  # Reset the start time when the game starts
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                        # Check if Winnie collides with the trophy
        if winnie.rect.colliderect(trophy.rect):
            win_screen()  # Show the win screen
            return  # Exit the game loop, stopping the timer

        # Fill the screen with a color (optional)
        screen.fill(background_color)  # Light Blue

        # Update all sprites
        all_sprites.update()

        # Calculate the camera offset
        camera_offset_x = winnie.rect.centerx - screen.get_width() // 2
        camera_offset_y = winnie.rect.centery - screen.get_height() // 2

        # Draw all sprites with the camera offset
        for sprite in all_sprites:
            screen.blit(sprite.image, (sprite.rect.x - camera_offset_x, sprite.rect.y - camera_offset_y))

        # Render the life counter
        life_text = font.render(f'Lives: {life}', True, text_color)  # White color
        screen.blit(life_text, (10, 10))  # Position at top-left corner

        # Render the stopwatch
        elapsed_time = time.time() - start_time
        hours, rem = divmod(elapsed_time, 3600)
        minutes, rem = divmod(rem, 60)
        seconds, milliseconds = divmod(rem, 1)
        stopwatch_text = f'{int(hours):02}:{int(minutes):02}:{int(seconds):02}:{int(milliseconds * 1000):03}'
        stopwatch_surface = font.render(stopwatch_text, True, text_color)
        screen.blit(stopwatch_surface, (screen.get_width() - 200, 10))  # Position at top-right corner, not touching the corner

        # Update the display
        pygame.display.flip()

        # Check if life is 0
        if life <= 0 and not game_over:
            game_over_screen()
            game_over = True  # Set game over flag
            break  # Exit the game loop to return to the main menu

        # Check if Winnie collides with the trophy
        if winnie.rect.colliderect(trophy.rect):
            win_screen(elapsed_time)  # Pass the elapsed time to display it
            game_loop() # Restarts the game

def win_screen(elapsed_time):
    screen.fill(background_color)
    
    # Format the elapsed time
    hours, rem = divmod(elapsed_time, 3600)
    minutes, rem = divmod(rem, 60)
    seconds, milliseconds = divmod(rem, 1)
    time_text = f'{int(hours):02}:{int(minutes):02}:{int(seconds):02}.{int(milliseconds * 1000000):06}'  # Show microseconds
    
    # Display win message and time
    draw_text("You Win!", large_font, title_color, 350, 250, shadow_color)
    draw_text(f"Time: {time_text}", font, text_color, 500, 400, shadow_color)

    pygame.display.flip()
    time.sleep(3)  # Show the win screen for 3 seconds
    
    # Return to the main menu instead of restarting the game
    main_menu(play_again=True)

        # Created By Not Sniw
        # Credits: Lafa Yette for the sprite images
        # My other friends for calling me Winnie
        # Inspired by games that makes you rage

# Run the loading screen, main menu, and game loop
loading_screen()
while True:
    main_menu(play_again=(life <= 0))
    life = 5  # Reset life for a new game
    game_over = False  # Reset game over flag
    game_loop()