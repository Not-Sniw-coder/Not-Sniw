chrome.runtime.onInstalled.addListener(() => {
    console.log('Basket Random Extension installed!');
  });