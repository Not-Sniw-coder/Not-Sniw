chrome.runtime.onInstalled.addListener(() => {
    console.log('Super liquid soccer Extension installed!');
  });