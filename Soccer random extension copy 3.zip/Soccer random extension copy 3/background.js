chrome.runtime.onInstalled.addListener(() => {
    console.log('Soccer Random Extension installed!');
  });